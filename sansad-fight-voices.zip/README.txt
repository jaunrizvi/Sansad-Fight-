SANSAD FIGHT — 3D browser game with uploaded hit audio

Run locally:
  python -m http.server 8000
Open http://localhost:8000

Deploy:
Upload the entire extracted folder (index.html AND audio folder) to Netlify Drop or another static host.
Do not upload index.html alone: the MP3 files in /audio are required.

Controls:
P1: A/D move, W jump, J punch, K kick, L special.
P2: Arrow keys move/jump, 1 punch, 2 kick, 3 special.
Mobile: touch controls for Player 1.

Voice:
The four MP3 files supplied in this chat are included and assigned as hit reactions:
- Narendra Modi: didi o didi clip
- Rahul Gandhi: khatam tata clip
- Mamata Banerjee: humbaa clip
- Nitin Gadkari and Yogi Adityanath: sajjan clip
Voice ON/OFF buttons control playback. Browser audio may require the first tap/click to unlock playback.

This is a cartoon parody game. Audio is user-provided; the assignments are playful game mappings and do not verify the speaker's identity. 2-player is local/shared keyboard, not online multiplayer.
